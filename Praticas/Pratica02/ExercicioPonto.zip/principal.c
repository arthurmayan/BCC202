//
//  principal.c
//  Ponto
//
//

// Para este exercício, implementar as funções faltantes para o TAD Ponto e submeter ponto.h, ponto.c e principal.c num arquivo compactado com extensão .zip. (manter os mesmos nomes dos arquivos).
#include <stdio.h>
#include "ponto.h"

int main(){
    
    Ponto* p1 = pto_cria(2.0,4.0);
    //ERRO Ponto* p2 = (Ponto*) malloc(sizeof(Ponto));
    //ERRO   Ponto p2;
    
    return 0;
}
