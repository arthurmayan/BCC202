//
//  ponto.c
//  Ponto
//
//  Created by Amanda Savio Nascimento e Silva on 26/01/21.
//

#include "ponto.h"
#include <stdlib.h>
#include <stdio.h>

struct ponto{
    float x, y;
    
};

Ponto* pto_cria(float x, float y){
    Ponto* aux = (Ponto*) malloc(sizeof(Ponto));
    if(aux==NULL)
    {
        printf("Memoria eh insuficiente");
        exit(1);
    }
    aux->x= x;
    aux->y = y;
    return aux;
    
    
    
}
void pto_libera(Ponto* p){
    
    
}
void pto_acessa(Ponto* p, float *x, float* y);
void pto_atribui(Ponto* p, float x, float y);
float pto_distancia(Ponto* p1, Ponto *p2);
void pto_imprime(Ponto* p1);

