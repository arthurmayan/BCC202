//
// Created by alex on 4/18/21.
//
#ifndef TP2Q2_ARVOREBINARIA_H
#define TP2Q2_ARVOREBINARIA_H
typedef long int Chave;

typedef struct{
  char string;
  Chave chave;
} Item;

typedef struct no{
    Item item;
    struct no *ponteiro_esquerda, *ponteiro_direita;
} No;

typedef No *Arvore;

//Funcao responsavel por fazer uma pesquisa de um registro(Item) na Arvore Binaria.
//Caso o registro exiata retorna 1, caso contrario 0.
int arvorePesquisa(Arvore, Chave, Item*);

//Funcao responsavel por inserir um registro(Item) na Arvore Binaria.
//Caso o registro tenha sido inserido com sucesso retorna 1, caso contrario ele ja existe e retorna 0.
int arvoreInsere(No**, Item);

//Funcao responsavel por criar um no Arvore Binaria.
//Retorna o endereco no qual o no esta alocado na memoria.
No* noCria(Item);

//Procedimento responsavel por inicializar uma Arvore Binaria.
void arvoreInicia(No**);

//Funcao Recursiva responsavel por retirar um registro da Arvore Binaria.
//Retorna 1 caso a retirada seja feita com sucesso, caso contrario o no nao existe e retorna 0.
int arvoreRetira(No**, Item);

//Procedimento auxiliar da fncao arvoreRetira, responsavel por pegar o no mais  a esquerda do no a diretira do no a ser
//retirado, e fazer a troca entre o no a ser retirado e o no encontrado.
//Tratamento da situacao no qual o no a ser retirado possui dois filhos.
void arvoreSucessor(No*, No**);

//Funcao Recursiva responsavel por imprimir os item dos no da Arvore Binaria
//Por meio do caminhamento Central
void imprimeArvore(No *ponteiro_no);

//Funcao responsavel po identificar se o strind do Item e um operador ou numero
//Retorna 1 se for operador, 0 se for um numero ou -1 caso a strind seja invalida
int operadorOuNumero(Item);

//Procedimento por gerar um chave e atrubuir esse valor a chave do Item
void geraChaveItem(Item*);

//Pocedimento que gera um vetor de Itens e insere tais item na Arvore Binaria
void criaRegistros(Arvore*, char*);

//
void preenchendoString(No *, char **, int*);
char* criaStringArvore(No*);

void liberaArvore(Arvore ponteiro_ponteiro_raiz);
void liberaNo(No *ponteiro_no);
#endif //TP2Q2_ARVOREBINARIA_H
