//
// Created by anton on 4/17/2021.
//

#ifndef PR04TUTORIA_LISTA_H
#define PR04TUTORIA_LISTA_H
typedef struct listaNo{
    char numero_operador[1];
    struct listaNo *proximo, *final;
} ListaNo;

typedef struct lista{
    ListaNo *primeiro, *final;
} Lista;

//Procedimento responsavel por inicializar uma lista
void lst_inicia(Lista*);

//Funcao responsavel por criar um registro da Lista
ListaNo* lst_cria(char*);

//Procedimento reponsavel por inserer um registro  na Lista
void lst_insere_final(Lista*, char*);

//Procedimento responsavel por imprimir todos os registro da Lista
void lst_imprime(Lista*);

//Procedimento responsavel por retirar um registro da Lista
void lst_retira(Lista*, char*);

//Funcao responsavel por verificar se a Lista esta vazia
int lst_vazia(Lista*);

//Procedimento responsavel por liberar a Lista (dsalocando todos seus nos(celula))
void lst_liberar(Lista*);

//Procedimento responsavel por inserir os conteudos de uma strind na Lista
void insereStringLista(Lista*, const char*, int);

//Funcao responsavel por calcular os registros da Lista
//Retorna o resultado desse calculo
int calculadora(Lista *l);

//Funcao responsavel por somar todos os registros da Lista
//Retorna a soma
int operadorOuNumeroLista(char *string);

//Funcao responsavel por converter uma string para inteiro
//Retorna a conversao
int operacao(int, char*, char*);

//Funcao responsavel por verificar qual operacao realizar sendo estas:
//1 = multiplicacao; 2 = divisao; 3 = soma; 4 = subtracao
//Retorna o resultado feito das operacoes
int converteStringInteiro(char *string);

//Verifica se a string na Lista e um operador ou numero
//Retorna 1 = multiplicacao; 2 = divisao; 3 = soma; 4 = subtracao; 0 = numero; -1 caso contrario
int somaLista(Lista *l);
#endif //PR04TUTORIA_LISTA_H