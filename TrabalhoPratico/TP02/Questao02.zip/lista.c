//
// Created by anton on 4/17/2021.
//

#include "lista.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//Procedimento responsavel por inicializar uma lista
void lst_inicia(Lista *l){
    l->primeiro = NULL;
    l->final = NULL;
}

//Funcao responsavel por criar um registro da Lista
ListaNo* lst_cria(char *numero_operador){
    ListaNo *aux = (ListaNo*) malloc(sizeof(ListaNo));
    strcpy(aux->numero_operador, numero_operador);
    aux->proximo = NULL;
    aux->final = NULL;
    return aux;
}

//Procedimento reponsavel por inserer um registro  na Lista
void lst_insere_final(Lista* l, char *nome){
    ListaNo *ultimo_no = lst_cria(nome);
    ListaNo *primeiro_no = l->primeiro;
    ListaNo *proximo_no;
    if(lst_vazia(l))
        l->primeiro = ultimo_no;
    else{
        while (primeiro_no != NULL){
            proximo_no = primeiro_no;
            primeiro_no = primeiro_no->proximo;
        }
        proximo_no->proximo = ultimo_no;
    }
}

//Procedimento responsavel por imprimir todos os registro da Lista
void lst_imprime(Lista *l){
    ListaNo *primeiro_no = l->primeiro;
    while (primeiro_no != NULL){
        printf("%s\n", primeiro_no->numero_operador);
        primeiro_no = primeiro_no->proximo;
    }
    printf("\n");
}

//Procedimento responsavel por retirar um registro da Lista
void lst_retira(Lista *l, char *numero_operado){
    if(lst_vazia(l))
        return;
    ListaNo *aux = l->primeiro;
    strcpy(numero_operado, aux->numero_operador);
    l->primeiro = aux->proximo;
    free(aux);
}

//Funcao responsavel por verificar se a Lista esta vazia
int lst_vazia(Lista *l){
    if(l->primeiro == NULL)
        return 1;
    return 0;
}

//Procedimento responsavel por liberar a Lista (dsalocando todos seus nos(celula))
void lst_liberar(Lista *l){
    ListaNo  *primeiro_no = l->primeiro;
    while (primeiro_no != NULL){
        ListaNo  *proximo_no = primeiro_no->proximo;
        free(primeiro_no);
        primeiro_no = proximo_no;
    }
}

//Procedimento responsavel por inserir os conteudos de uma strind na Lista
void insereStringLista(Lista *l, const char *string, int tamanho_string){
    char *string_alocado = (char*) malloc(sizeof(char));
    for(int i = 0; i < tamanho_string; i++){
        string_alocado[0] = string[i];
        string_alocado[1] = '\0';
        lst_insere_final(l, string_alocado);
    }
    free(string_alocado);
}

//Funcao responsavel por calcular os registros da Lista
//Retorna o resultado desse calculo
int calculadora(Lista *l){
    char *numero_operador = malloc(sizeof(char));
    Lista lista_aux;
    lst_inicia(&lista_aux);
    ListaNo *ponteiro_aux = l->primeiro;
    int operador;
    char *primeiro;
    char *segundo;
    int resultado;
    int operador_ou_numero;
    ListaNo *ponteiro_aux_retirada = NULL;

    //Laco responsavel por verificar as operacoes
    while (ponteiro_aux != NULL){
        operador_ou_numero = operadorOuNumeroLista(ponteiro_aux->numero_operador);
        operador = operador_ou_numero;

        //Primeira verificao, descobrir se na lista esta posicao e um operador
        //Caso verdadeiro pegar as informacoes, fazer a operacao e guardar o resultado em uma lista auxiliar
        if(operador_ou_numero >= 1 && operador_ou_numero <= 4){
            //operador = ponteiro_aux->numero_operador;
            operador_ou_numero = operadorOuNumeroLista(ponteiro_aux->proximo->numero_operador);

            //Segundo verificacao, descobrir se for um numero
            //caso verdadeiro ha duas posibilidades, quando for mutiplicacao ou divisao a operacao, pegar os dois
            //numeros e "inutilizar" os registros pegos da lista atribuino 'A' a eles
            //Inutilizacao necessaria devido a ser um laco, porem so nos casos de multiplicacao e divisao
            if(operador_ou_numero == 0){
                primeiro = ponteiro_aux->proximo->numero_operador;
                operador_ou_numero = operadorOuNumeroLista(ponteiro_aux->proximo->proximo->numero_operador);
                if(operador_ou_numero == 0){
                    segundo = ponteiro_aux->proximo->proximo->numero_operador;
                    resultado = operacao(operador, primeiro, segundo);
                    sprintf(numero_operador, "%d", resultado);
                    lst_insere_final(&lista_aux, numero_operador);
                    strcpy(ponteiro_aux->numero_operador, "A");
                    strcpy(ponteiro_aux->proximo->numero_operador, "A");
                    strcpy(ponteiro_aux->proximo->proximo->numero_operador, "A");
                }
                else{

                    //Nao ha mais 2 numeros e um operador para ser pego na lista, portanto, pegar o operador
                    //e o numero seguinte e fazer a operacao com os valores que estao na lista auxiliar
                    if(!lst_vazia(&lista_aux)){
                        lst_retira(&lista_aux, numero_operador);
                        primeiro = numero_operador;
                        segundo = ponteiro_aux->proximo->numero_operador;
                        resultado = operacao(operador, primeiro, segundo);
                        sprintf(numero_operador, "%d", resultado);
                        lst_insere_final(&lista_aux, numero_operador);
                    }
                }
            }
        }
        ponteiro_aux = ponteiro_aux->proximo;
    }

    int resultado_expressao = somaLista(&lista_aux);
    free(numero_operador);
    lst_liberar(&lista_aux);
    return resultado_expressao;
}

//Funcao responsavel por somar todos os registros da Lista
//Retorna a soma
int somaLista(Lista *l){
    ListaNo *ponteiro_aux = l->primeiro;
    int soma = 0;
    while (ponteiro_aux != NULL){
        soma = soma + converteStringInteiro(ponteiro_aux->numero_operador);
        ponteiro_aux = ponteiro_aux->proximo;
    }
    return soma;
}

//Funcao responsavel por converter uma string para inteiro
//Retorna a conversao
int converteStringInteiro(char *string){
    char *lixo;
    return (int) strtol(string, &lixo,10);
}

//Funcao responsavel por verificar qual operacao realizar sendo estas:
//1 = multiplicacao; 2 = divisao; 3 = soma; 4 = subtracao
//Retorna o resultado feito das operacoes
int operacao(int operador, char *numero1, char *numero2){
    switch (operador){
        case 1:
            return converteStringInteiro(numero1) * converteStringInteiro(numero2);
        case 2:
            return converteStringInteiro(numero1) / converteStringInteiro(numero2);
        case 3:
            return converteStringInteiro(numero1) + converteStringInteiro(numero2);
        case 4:
            return converteStringInteiro(numero1) - converteStringInteiro(numero2);
        default:
            break;
    }
    return 0;
}

//Verifica se a string na Lista e um operador ou numero
//Retorna 1 = multiplicacao; 2 = divisao; 3 = soma; 4 = subtracao; 0 = numero; -1 caso contrario
int operadorOuNumeroLista(char *string){
    if(string == NULL)
        return -1;
    if(strcmp(string, "*") == 0)
        return 1;
    else if(strcmp(string, "/") == 0)
        return 2;
    else if(strcmp(string, "+") == 0)
        return 3;
    else if(strcmp(string, "-") == 0)
        return 4;
    else if(string[0] > '/' && string[0] < ':')
        return 0;
    else
        return  -1;
}