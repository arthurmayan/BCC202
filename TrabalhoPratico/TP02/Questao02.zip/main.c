#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "arvoreBinaria.h"
#include "lista.h"

//Procedimento responsavel por tratar as precedencia dos operadores da string(expressao)
void alteraPrecedenciaOperadores(char**, char**, int*, char);

//Funcao reponsavel por verificar quais operadores da string(expressao)
//Retorna a string devidamente tratada com as ordem de precedencia
char* verficaPrecedenciaOperadores(char *, int);

//Procedimento responsavel por imprimir uma string
void imprimeString(char*, int);

//Procedimento responsavel por copiar uma string para outra porem modificada, sendo tais modificacoes
//Quando a string possui mais de 3 elemetos coloca '+' na primeira posicao do string_destino[]
void strcpyModificado(char string_destino[], char string_partida[]);

//Procedimento responsavel por trocar dois caracteres
void trocaCaracter(char *, char *);

//Procedimento reponsavel por trocar duas possicoes de uma string
void trocaString(char *string, int i, int j);

int main(){
    Arvore arvore;
    Lista lista;
    arvoreInicia(&arvore);
    lst_inicia(&lista);
    char expressao[250], string[251];
    printf("Digite a expressao: ");
    fgets(expressao, 250, stdin);
    //scanf("%s", expressao);
    fflush(stdin);
    strcpyModificado(string, expressao);
    char *string_final = verficaPrecedenciaOperadores(string, (int) strlen(string));
    criaRegistros(&arvore, string_final);
    char *string_arvore = criaStringArvore(arvore);
    insereStringLista(&lista, string_arvore, (int) strlen(string_arvore));
    expressao[strlen(expressao)-1] = '\0';
    printf("%s = %d\n", expressao, calculadora(&lista));
    free(string_final);
    free(string_arvore);
    lst_liberar(&lista);
    liberaArvore(arvore);
    //implementar o liberar da arvore
    return 0;
}

//Procedimento responsavel por copiar uma string para outra porem modificada, sendo tais modificacoes
//Quando a string possui mais de 3 elemetos coloca '+' na primeira posicao do string_destino[]
void strcpyModificado(char string_destino[], char string_partida[]){
    unsigned int tamanho_string;
    tamanho_string = strlen(string_partida);
    if((tamanho_string == 4) && (string_partida[1] == '+' || string_partida[1] == '-')){
        for(int i = 0 ; i <= tamanho_string; i++){
            string_destino[i] = string_partida[i];
        }
        string_destino[tamanho_string] = '\0';
    }else{
        string_destino[0] = '+';
        for(int i = 0 ; i <= tamanho_string; i++){
            string_destino[i+1] = string_partida[i];
        }
        string_destino[tamanho_string+1] = '\0';
    }
}

//Funcao reponsavel por verificar quais operadores da string(expressao)
//Retorna a string devidamente tratada com as ordem de precedencia
char* verficaPrecedenciaOperadores(char *string, int tamanho_string){
    char *string_aux = malloc(tamanho_string * sizeof(char));
    int indice_string_aux = 0;

    for(int i = 0 ; i < tamanho_string; i++){
        if(string[i] == '*' || string[i] == '/')
            alteraPrecedenciaOperadores(&string, &string_aux, &indice_string_aux, string[i]);
    }

    for(int i = 0 ; i < tamanho_string; i++){
        if(string[i] == '+' || string[i] == '-')
            alteraPrecedenciaOperadores(&string, &string_aux, &indice_string_aux, string[i]);
    }

    return string_aux;
}

//Procedimento responsavel por tratar as precedencia dos operadores da string(expressao)
void alteraPrecedenciaOperadores(char **string_principal, char **string_aux, int *indice_string_aux, char operador){
    char string_anterior;
    char string_operador;
    char string_sucessor;
    int contador_auxiliar = 0;
    int indice_invalido;
    unsigned int tamanho_string_principal =  strlen((*string_principal));

    //Laco responsavel por identificar a posicao no qual o operador esta na string
    while(contador_auxiliar < tamanho_string_principal){
        char operador_while = (*string_principal)[contador_auxiliar];
        if(operador_while == operador){
            indice_invalido = contador_auxiliar - 1;
            if(indice_invalido < 0){
                string_anterior = 'A';
            }else{
                string_anterior = (*string_principal)[contador_auxiliar - 1];
            }
            string_operador = (*string_principal)[contador_auxiliar];
            string_sucessor = (*string_principal)[contador_auxiliar + 1];

            //verificacao responsavel para nao pegar os mesmos valores novamente
            //Caso verdadeiro pega as 4 posicoes reponsavel por ter o operador e os dois numeros
            //Valido somente para divisao ou multiplicacao
            //"Inutiliza" as possicoes pegadas atribuindo 'A' a elas
            if(string_anterior != 'A'){
                //Pegando as 4 informacoes
                trocaCaracter(&string_anterior, &string_operador);
                (*string_aux)[*indice_string_aux] = string_anterior;
                (*string_aux)[*indice_string_aux+1] = string_operador;
                (*string_aux)[*indice_string_aux+2] = string_sucessor;
                *indice_string_aux = *indice_string_aux + 3;

                //Inutilizacao das posicoes
                (*string_principal)[contador_auxiliar - 2] = 'A';
                (*string_principal)[contador_auxiliar - 1] = 'A';
                (*string_principal)[contador_auxiliar] = 'A';
                (*string_principal)[contador_auxiliar + 1] = 'A';
                break;
            }
            else{
                //Tratandos os casos que sao adicao e subtracao
                //Pega somente duas posicoes do vetor e "inutiliza" elas

                //Pegando as duas posicoes
                (*string_aux)[*indice_string_aux] = string_operador;
                (*string_aux)[*indice_string_aux+1] = string_sucessor;
                *indice_string_aux = *indice_string_aux + 2;

                //Inutilizando as duas posicoes
                (*string_principal)[contador_auxiliar] = 'A';
                (*string_principal)[contador_auxiliar + 1] = 'A';
                break;
            }
        }
        contador_auxiliar++;
    }
}

//Procedimento responsavel por trocar dois caracteres
void trocaCaracter(char *a, char *b){
    char aux = (*a);
    (*a) = (*b);
    (*b) = aux;
}

//Procedimento responsavel por imprimir uma string
void imprimeString(char *string, int tamanho_string){
    for(int i = 0; i < tamanho_string; i++)
        printf("%c", string[i]);
    printf("\n");
}

//Procedimento reponsavel por trocar duas possicoes de uma string
void trocaString(char *string, int i, int j){
    char aux = string[i];
    string[i] = string[j];
    string[j] = aux;
}