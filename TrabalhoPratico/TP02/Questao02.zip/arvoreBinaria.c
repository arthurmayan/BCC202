//
// Created by alex on 4/18/21.
//

#include "arvoreBinaria.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//Variavel global responsavel por controlar a quantidade de registro na arvore binaria
int quantidade_registro_arvore = 0;

//Procedimento responsavel por inicializar uma Arvore Binaria.
void arvoreInicia(No **ponteiro_ponteiro_raiz){
    *ponteiro_ponteiro_raiz = NULL;
}

//Funcao responsavel por inserir um registro(Item) na Arvore Binaria.
//Caso o registro tenha sido inserido com sucesso retorna 1, caso contrario ele ja existe e retorna 0.
int arvoreInsere(No **ponteiro_ponteiro_raiz, Item item_x){
    No **ponteiro_ponteiro_auxiliar = ponteiro_ponteiro_raiz;
    while (*ponteiro_ponteiro_auxiliar != NULL){
        if (item_x.chave < (*ponteiro_ponteiro_auxiliar)->item.chave)
            ponteiro_ponteiro_auxiliar = &((*ponteiro_ponteiro_auxiliar)->ponteiro_esquerda);
        else if (item_x.chave > (*ponteiro_ponteiro_auxiliar)->item.chave)
            ponteiro_ponteiro_auxiliar = &((*ponteiro_ponteiro_auxiliar)->ponteiro_direita);
        else
            return 0;
    }

    *ponteiro_ponteiro_auxiliar = noCria(item_x);
    quantidade_registro_arvore++;
    return 1;
}

//Funcao Recursiva responsavel por retirar um registro da Arvore Binaria.
//Retorna 1 caso a retirada seja feita com sucesso, caso contrario o no nao existe e retorna 0.
int arvoreRetira(No **ponteiro_ponteiro_no, Item item_x){
    No *ponteiro_auxiliar;
    //Caso Base
    if (*ponteiro_ponteiro_no == NULL)
        return 0;

    //Caminhamento para o no a esquerda na Arvore Binaria
    if (item_x.chave < (*ponteiro_ponteiro_no)->item.chave)
        return arvoreRetira(&((*ponteiro_ponteiro_no)->ponteiro_esquerda), item_x);

    //Caminhamento para o no a direita na Arvore Binaria
    if (item_x.chave > (*ponteiro_ponteiro_no)->item.chave)
        return arvoreRetira(&((*ponteiro_ponteiro_no)->ponteiro_direita), item_x);

    //Quando o no e folha, retirada simples, apenas o retira
    if ((*ponteiro_ponteiro_no)->ponteiro_esquerda == NULL && (*ponteiro_ponteiro_no)->ponteiro_direita == NULL){
        free(*ponteiro_ponteiro_no);
        *ponteiro_ponteiro_no = NULL;
        quantidade_registro_arvore--;
        return 1;
    }

    //Quando o no a ser retirado possui filho a esquerda e a diretira e nulo
    if((*ponteiro_ponteiro_no)->ponteiro_esquerda != NULL && (*ponteiro_ponteiro_no)->ponteiro_direita == NULL){
        ponteiro_auxiliar = *ponteiro_ponteiro_no;
        *ponteiro_ponteiro_no = (*ponteiro_ponteiro_no)->ponteiro_esquerda;
        free(ponteiro_auxiliar);
        quantidade_registro_arvore--;
        return 1;
    }

    //Quando o no a ser retirado possui filho a direita e a esquerda e nulo
    if((*ponteiro_ponteiro_no)->ponteiro_direita != NULL && (*ponteiro_ponteiro_no)->ponteiro_esquerda == NULL){
        ponteiro_auxiliar = *ponteiro_ponteiro_no;
        *ponteiro_ponteiro_no = (*ponteiro_ponteiro_no)->ponteiro_direita;
        free(ponteiro_auxiliar);
        quantidade_registro_arvore--;
        return 1;
    }

    //Quando o no possui dois filhos, filho equerda e direita nao nulos
    arvoreSucessor(*ponteiro_ponteiro_no, &((*ponteiro_ponteiro_no)->ponteiro_direita));
    quantidade_registro_arvore--;
    return 1;
}

//Funcao responsavel por fazer uma pesquisa de um registro(Item) na Arvore Binaria.
//Caso o registro exiata retorna 1, caso contrario 0.
int arvorePesquisa(Arvore ponteiro_raiz, Chave chave_x, Item *ponteiro_x){
    No *ponteiro_auxiliar = ponteiro_raiz;
    while (ponteiro_auxiliar != NULL){
        if (chave_x == ponteiro_auxiliar->item.chave){
            *ponteiro_x = ponteiro_auxiliar->item;
            return 1;
        }
        else if (chave_x > ponteiro_auxiliar->item.chave)
            ponteiro_auxiliar = ponteiro_auxiliar->ponteiro_direita;
        else
            ponteiro_auxiliar = ponteiro_auxiliar->ponteiro_esquerda;
    }
    return 0;
}

//Procedimento auxiliar da fncao arvoreRetira, responsavel por pegar o no mais  a esquerda do no a diretira do no a ser
//retirado, e fazer a troca entre o no a ser retirado e o no encontrado.
//Tratamento da situacao no qual o no a ser retirado possui dois filhos.
void arvoreSucessor(No *ponteiro_no, No **ponteiro_ponteiro_no_direita){
    No *ponteiro_auxiliar;
    //Caso Base
    if((*ponteiro_ponteiro_no_direita)->ponteiro_esquerda != NULL){
        arvoreSucessor(ponteiro_no, &(*ponteiro_ponteiro_no_direita)->ponteiro_esquerda);
        return;
    }
    ponteiro_no->item = (*ponteiro_ponteiro_no_direita)->item;
    ponteiro_auxiliar = *ponteiro_ponteiro_no_direita;
    *ponteiro_ponteiro_no_direita = (*ponteiro_ponteiro_no_direita)->ponteiro_direita;
    free(ponteiro_auxiliar);
}

//Funcao Recursiva responsavel por imprimir os item dos no da Arvore Binaria
//Por meio do caminhamento Central
void imprimeArvore(No *ponteiro_no){
    if(ponteiro_no == NULL)
        return;
    printf("%c\n", ponteiro_no->item.string);
    imprimeArvore(ponteiro_no->ponteiro_esquerda);
    imprimeArvore(ponteiro_no->ponteiro_direita);
}

//Funcao responsavel pegar da arvore por caminhamento Pre-Ordem os resgistros da arvore binaria
//somente o conteudo da string (Item) que ele pega
void preenchendoString(No *ponteiro_no, char **string, int *indice_string){
    //Caso  Base
    if(ponteiro_no == NULL)
        return;
    (*string)[*indice_string] = ponteiro_no->item.string;
    *indice_string = *indice_string + 1;
    preenchendoString(ponteiro_no->ponteiro_esquerda, string, indice_string);
    preenchendoString(ponteiro_no->ponteiro_direita, string, indice_string);
}

//Funcao responsavel por criar os registros do tipo Item e inserer na Arvore Binaria
//Pega as informacoes de um vetor de string
void criaRegistros(Arvore *ponteiro_raiz, char *string){
    unsigned int tamanho_string = strlen(string);
    for(int i = 0; i < tamanho_string; i++){
        Item item_x;
        item_x.string = string[i];
        geraChaveItem(&item_x);
        arvoreInsere(ponteiro_raiz, item_x);
    }
}

//Procedimento por gerar um chave e atrubuir esse valor a chave do Item
void geraChaveItem(Item *item_x){
    static long int valor_chave_operador = 1000000;
    static long int valor_chave_numero = 5000;

    //Tratando a primeira insercao na arvores (so cai nessa condicao uma vez, quando a arvore esta vazia)
    if(valor_chave_numero > 5000){
        if(operadorOuNumero((*item_x)) == 1){
            (*item_x).chave = valor_chave_operador;
            valor_chave_operador += 10000;
            valor_chave_numero = valor_chave_operador + 1000;
            return;
        }
        else if(operadorOuNumero((*item_x)) == 0){
            (*item_x).chave = valor_chave_numero;
            valor_chave_numero--;
        }
    }

    //Tratando todas as outras insercoes
    if(operadorOuNumero((*item_x)) == 1){
        (*item_x).chave = valor_chave_operador;
        valor_chave_operador += 1;
        valor_chave_numero += 1000;
        return;
    }
    else if(operadorOuNumero((*item_x)) == 0){
        (*item_x).chave = valor_chave_numero;
        valor_chave_numero--;
    }

}

//Funcao responsavel por criar um no Arvore Binaria.
//Retorna o endereco no qual o no esta alocado na memoria.
No* noCria(Item item_x){
    No *ponteiro_auxiliar = (No*) malloc(sizeof(No));
    ponteiro_auxiliar->item = item_x;
    ponteiro_auxiliar->ponteiro_esquerda = NULL;
    ponteiro_auxiliar->ponteiro_direita = NULL;
    return ponteiro_auxiliar;
}

//Funcao responsavel po identificar se o strind do Item e um operador ou numero
//Retorna 1 se for operador, 0 se for um numero ou -1 caso a strind seja invalida
int operadorOuNumero(Item item_x){
    if(item_x.string == '*')
        return 1;
    if(item_x.string == '/')
        return 1;
    if(item_x.string == '-')
        return 1;
    if(item_x.string == '+')
        return 1;
    if(item_x.string > '/' && item_x.string < ':')
        return 0;
    else
        return  -1;
}

//Funcao Responsavel por criar uma string nos moldes de uma Arvore Binaria
char* criaStringArvore(No *ponteiro_no){
    char *string_aux = (char*) malloc(quantidade_registro_arvore * sizeof(char));
    int indice_string = 0;
    preenchendoString(ponteiro_no, &string_aux, &indice_string);
    string_aux[quantidade_registro_arvore] = '\0';
    return string_aux;
}

//Funcao responsavel por liberar todos os nos da Arvore Binaria
void liberaArvore(Arvore ponteiro_ponteiro_raiz){
    if(ponteiro_ponteiro_raiz == NULL)
        return;
    liberaArvore((*ponteiro_ponteiro_raiz).ponteiro_esquerda);
    liberaArvore((*ponteiro_ponteiro_raiz).ponteiro_direita);
    free(ponteiro_ponteiro_raiz);
    ponteiro_ponteiro_raiz = NULL;
    quantidade_registro_arvore = 0;
}

