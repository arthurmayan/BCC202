﻿#include "quickSort.h"

// Escolha do pivo numa mediana de 3 valores
int pivo_mediana(int *v, int esquerda, int direita)
{
    //procura a mediana entre esquerda, meio e direita
    int meio = (esquerda + direita) / 2;

    int a = v[esquerda];
    int b = v[meio];
    int c = v[direita];

    int indice_do_meio; //índice da mediana

    // compara para saber qual o maior elemento. Menor elemento. E o elemento do meio.
    if (a < b) 
    {
        if (b < c) 
        {
            indice_do_meio = meio; // a < b < c

        } else 
        {
            if (a < c) 
            {
                indice_do_meio = direita; //a < c < b

            } else 
            {
                indice_do_meio = esquerda; //c < a < b

            }
        }
    } else 
    {
        if (c < b) 
        {
            indice_do_meio = meio; //c < b < a 
        } else 
        {
            if (c < a) 
            {
                indice_do_meio = direita; // b < c < a 
            } else {
                indice_do_meio = esquerda; // b < a < c
            }
        }
    }
    troca(v, indice_do_meio, direita); //coloca o elemento da mediana na variavel direita


}

//Quicksort MEDIANA
void quickSort_mediana(int *v, int esquerda, int direita)
{
    while(esquerda < direita)
    {
        if(direita - esquerda <= 10)
        {
            insertionSort(v, esquerda, direita);
            break;
        }
        else
        {
            int pivo = particao_mediana(v, esquerda, direita);

            if(pivo - esquerda < direita - pivo) // esquerda
            {
                quickSort_mediana(v, esquerda, pivo - 1);
                esquerda = pivo + 1;
            }
            else{
                quickSort_mediana(v, pivo + 1, direita); // direita
                direita = pivo - 1;
            }
        }
    }
}

// Particao do quicksort
int particao_mediana(int *v, int esquerda, int direita) 
{
    pivo_mediana(v, esquerda, direita);

    int pivo = v[direita]; // colocamos o pivo no ultimo elemento
    int i = esquerda - 1;
    int j;
    
    // Os elementos que são menores ou iguais ao pivo, serão colocados do lado esquerdo
    for (j = esquerda; j <= direita - 1; j++) // da esquerda para a direita 
    {
        if (v[j] <= pivo) 
        {
            i = i + 1;
            troca(v, i, j);
        }
    }

    troca(v, i + 1, direita); // coloca o pivô na posição de ordenação

    return i + 1; //retorna a posição do pivô
}

