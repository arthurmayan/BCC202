#include "quickSort.h"

// implementação da escolha do pivo ALEATORIA
int pivoAleatorio(int *v, int esquerda, int direita)
{    
    //sorteia um valor aleatorio pelo indice do vetor.
    int valor;
    double sortear;
    sortear = (double) rand () / ((double) RAND_MAX + 1);
    valor = sortear * (direita - esquerda + 1);
    int aleatorio = esquerda + valor;
    
    // Trocamos o valor que esta na direita(final) para o valor do pivo aleatorio
    // para ser usado na particao
    troca(v, aleatorio, direita);

}

// impĺementação quickSort ALEATORIO
void quickSort_aleatorio(int *v, int esquerda, int direita)
{
    while(esquerda < direita)
    {
        if(direita - esquerda <= 10)
        {
            insertionSort(v, esquerda, direita);
            break;
        }
        else
        {
            int pivo = particao_aleatorio(v, esquerda, direita);

            if(pivo - esquerda < direita - pivo) // esquerda 
            {
                quickSort_aleatorio(v, esquerda, pivo - 1);
                esquerda = pivo + 1;
            }
            else
            {
                quickSort_aleatorio(v, pivo + 1, direita); // direita 
                direita = pivo - 1;
            }
        }
    }
}

// Particao do quicksort
int particao_aleatorio(int *v, int esquerda, int direita) 
{
    pivoAleatorio(v, esquerda, direita);

    int pivo = v[direita]; //  Colocamos o pivo como o ultimo termo

    int i = esquerda - 1;
    int j;
    
    for (j = esquerda; j <= direita - 1; j++)  // da esquerda para a direita 
    {
        if (v[j] <= pivo) 
        {
            i = i + 1;
            troca(v, i, j);
        }
    }
    // Os elementos que são menores ou iguais ao pivo, serão colocados do lado esquerdo
    
    troca(v, i + 1, direita);  //coloca o pivô na posição de ordenação
    return i + 1; //retorna a posição do pivô
}