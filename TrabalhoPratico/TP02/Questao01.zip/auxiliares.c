#include "quickSort.h"

// Prenchee o vetor com números aleatorios de 0 a MAX
void sortear(int *v, int tam)
{
    srand(time(NULL));

    printf("\nVocê deseja números de 0 até quanto?\n");
    int max;
    scanf("%d", &max);

    for (int i = 0; i < tam; i++)
    {
        v[i] = rand() % max;
    }
}

// Pede o usuario para digitar os valores para preecher o vetor
void escolherValores(int *v, int tam)
{
    printf("\nDigite os valores que você deseja: ");
    for (int i = 0; i < tam; i++)
    {
        scanf("%d", &v[i]);
    }
}

// Opcode para prencheer o vetor com numeros aleatorios a escolha do usuario
void preencher_vetor(int *vetor, int tam, int opcode)
{
    if (opcode == 1)
    {
        sortear(vetor, tam);
    }
    else if (opcode == 2)
    {
        escolherValores(vetor, tam);
    }

    printf("\n************************************************************\n");

}

// Define se o pivo vai ser por meio aleatorio ou por mediana
void escolhaPivo(int *vetor, int tamanho_vetor, int opcode)
{
    if(opcode == 1)
    {
        quickSort_aleatorio(vetor, 0, tamanho_vetor - 1);
    }
    else if (opcode == 2)
    {
        quickSort_mediana(vetor, 0, tamanho_vetor - 1);

    }
}

// Coloca X no lugar de Y
void troca(int *v, int x, int y)
{
    int aux = v[x];
    v[x] = v[y];
    v[y] = aux;
}

// Impressão do vetor
void imprimir(int *v, int tam) 
{
    for (int i = 0; i < tam; i++) 
    {
        printf("%d ", v[i]);
    }
    printf("\n");
}

// Implementação do insertionSort
void insertionSort(int *v, int esquerda, int direita)
{
    // Um número compara com o seu antecessor
    // Caso for maior, troca de posição e compara com todos os elementos que antecedem sucessivamente
    int aux, j;

    for(int i = esquerda + 1; i <= direita; i++)
    {
        aux = v[i];
        j = i;
        
        while(j > esquerda && v[j-1] > aux)
        {
            v[j] = v[j-1];
            j--;
        }

        v[j] = aux;
    }
}


