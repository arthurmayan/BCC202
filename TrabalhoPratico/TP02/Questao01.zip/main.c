#include "quickSort.h"

int main()
{
    printf("************************* QUICKSORT ************************\n\n");

    printf("Digite o tamanho do vetor que você deseja ordenar:\n");
    int tamanho_vetor;
    scanf("%d", &tamanho_vetor);

    printf("\n************************************************************\n");

    printf("\nDigite\n");
    printf("1 - Caso queira um vetor com valores aleatorios\n2 - Para escolher os valores do vetor\n\n");
    int opcode;
    scanf("%d", &opcode);

    printf("\n************************************************************\n");

    int vetor[tamanho_vetor];

    preencher_vetor(vetor, tamanho_vetor, opcode);

    printf("\nVocê deseja fazer a escolha do pivo do Quicksort como?\n");
    printf("1 - Aleatorio\n2 - Mediana\n\n");
    scanf("%d", &opcode);

    printf("\n************************************************************\n\n");

    printf("Vetor sem ordenar: ");
    imprimir(vetor, tamanho_vetor);

    escolhaPivo(vetor, tamanho_vetor, opcode);

    printf("\nVetor ordenado: ");
    imprimir(vetor, tamanho_vetor);

    printf("\n************************************************************\n\n");


    return 0;
}

