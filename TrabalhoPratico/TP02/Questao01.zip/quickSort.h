#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// FUNÇÕES AUXILIARES
void sortear(int *v, int tam);
void escolherValores(int *v, int tam);
void preencher_vetor(int *vetor, int tam, int opcode);
void escolhaPivo(int *vetor, int tamanho_vetor, int opcode);

void troca(int *v, int x, int y);
void imprimir(int *v, int tam);

// INSERTIONSORT
void insertionSort(int *v, int esquerda, int direita);

// PIVO ALEATORIO
void quickSort_aleatorio(int *v, int esquerda, int direita);
int pivoAleatorio(int *v, int inicio, int fim);
int particao_aleatorio(int *v, int esquerda, int direita);

// PIVO MEDIANA
void quickSort_mediana(int *v, int esquerda, int direita);
int pivo_mediana(int *v, int esquerda, int direita);
int particao_mediana(int *v, int esquerda, int direita);


